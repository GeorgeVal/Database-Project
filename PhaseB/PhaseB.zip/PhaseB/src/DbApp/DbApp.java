package DbApp;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Random;
import java.util.Scanner;

public class DbApp {
	private Connection conn;
	
	public DbApp() {
		try {
			Class.forName("org.postgresql.Driver");
			System.out.println("Driver Found!");
		} catch (ClassNotFoundException e) {
			System.out.println("Driver not found!");
		}
	}
	
	//implements 1.1 connection to database
	public void dbConnect(String ip, String dbName, String username, String password) {
		try {
			conn = DriverManager.getConnection("jdbc:postgresql://"+ip+":5432/"+dbName, username, password);
			System.out.println("Connection established : "+conn);
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	//implements 1.1 disconnect from database
	public void dbDisconnect() {
		try {
			System.out.println("Closing Connection..");
			conn.close();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}
	
//implements 1.2 for both phaseA and phaseB databases	
public void showLabGrades(String amka, int academic_year, String academic_season) {
        
        try {
            PreparedStatement pst = conn.prepareStatement("select * from \"Person\" where amka = ?");
            pst.setString(1, amka);
            ResultSet res = pst.executeQuery();
            
            while (res.next()) {
                System.out.println("Student: " + res.getString(2) + " " + res.getString(3) + " " + res.getString(4));
                System.out.println("AMKA: " + res.getString(1));
                System.out.println("email: " + res.getString(5));
            }
            
            pst = conn.prepareStatement("select * from find_labmodule_grade(?,?::semester_season_type,?)");
            pst.setInt(1, academic_year);
            pst.setString(2, academic_season);
            pst.setString(3, amka);
            res = pst.executeQuery();
            
            while (res.next()) {
                System.out.println("Course_code: " + res.getString(1) + " Title: " + res.getString(2) + " Grade: " + res.getInt(3));
            }
            
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        
    }
	
	//implements 1.3 for phaseA database
	public void insertLabModulesA(String course_code, int serial_number, int LMnum, int teamNum) {
        System.out.println("Inserting Random LabModules");
        Random rand = new Random();
        String lab_type;
        double lab_prop;
        int module_num;
        
        try {
            PreparedStatement pst; 
            Statement st = conn.createStatement() ;

            for(int i=0; i<LMnum; i++) {
            	pst = conn.prepareStatement("insert into \"LabModule\"values(?::labmodule_type,?,?,?,?,?,?) ");
                lab_prop = rand.nextDouble();
                module_num=rand.nextInt(100000);
                if(lab_prop > 0.2 ) {
                    lab_type = "lab_exercise";
                }
                else lab_type = "project";
                
                pst.setString(1,lab_type);
                pst.setString(2, "LabModule "+i);
                pst.setInt(3, rand.nextInt(4)+2); 
                pst.setInt(4, rand.nextInt(100));
                if(st.executeQuery("select module_no from \"LabModule\" where module_no="+module_num) != null) {
                	ResultSet rt = st.executeQuery("select max(module_no) from \"LabModule\"");
                	rt.next();
                	module_num = rt.getInt(1)+1;
                }
                pst.setInt(5, module_num); 
                pst.setInt(6, serial_number);
                pst.setString(7, course_code);
                
                pst.executeUpdate();
                	st.executeQuery("select * from insert_workgroup_outer("+module_num+","+teamNum+")");
                	pst =conn.prepareStatement(" update \"WorkGroup\" set grade="+(int) Math.round(rand.nextGaussian()*2+6)+"where module_no="+module_num);
                	pst.executeUpdate();
                
                
            }
        }catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
	
	//implements 1.3 for phaseB database
	public void insertLabModulesB(String course_code, int serial_number, int LMnum, int teamNum) {
        System.out.println("Inserting Random LabModules");
        Random rand = new Random();
        String lab_type;
        double lab_prop;
        int module_num;
        
        try {
            PreparedStatement pst; 
            Statement st = conn.createStatement() ;

            for(int i=0; i<LMnum; i++) {
            	pst = conn.prepareStatement("insert into \"LabModule\" values(?,?,?,?::labmodule_type,?,?,?) ");
                lab_prop = rand.nextDouble();
                module_num=rand.nextInt(100000);
                if(lab_prop > 0.2 ) {
                    lab_type = "lab_exercise";
                }
                else lab_type = "project";
                
                pst.setString(4,lab_type);
                pst.setString(5, "LabModule "+i);
                pst.setInt(6, rand.nextInt(4)+2); //possible variable
                pst.setInt(7, rand.nextInt(100));
                if(st.executeQuery("select module_no from \"LabModule\" where module_no="+module_num) != null) {
                	ResultSet rt = st.executeQuery("select max(module_no) from \"LabModule\" ");
                	rt.next();
                	module_num = rt.getInt(1)+1;
                }
                pst.setInt(3, module_num); 
                pst.setInt(2, serial_number);
                pst.setString(1, course_code);
                
                pst.executeUpdate();
                	st.executeQuery("select * from insert_workgroup_outer("+module_num+","+teamNum+")");
                	pst =conn.prepareStatement(" update \"Workgroup\" set grade="+(int) Math.round(rand.nextGaussian()*2+6)+"where module_no="+module_num);
                	pst.executeUpdate();
                
                
            }
        }catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
	
	//implements 1.4 for phaseA database
	public void insert_RandomLabModulesA(String subject, int LMnum, int WGnum) {
		Statement st;
		try {
			st = conn.createStatement();
			
			ResultSet res = st.executeQuery("select course_code,serial_number from \"CourseRun\" where course_code like '"+subject+"%' and exam_percentage<100");
			
			while (res.next()) {
				
				insertLabModulesA(res.getString(1),res.getInt(2),LMnum,WGnum);
				
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
	}
	//implements 1.4 for phaseB database
	public void insert_RandomLabModulesB(String subject, int LMnum, int WGnum) {
		Statement st;
		try {
			st = conn.createStatement();
			
			ResultSet res = st.executeQuery("select course_code,serial_number from \"CourseRun\" where course_code like '"+subject+"%' and exam_percentage<100");
			
			while (res.next()) {
				
				insertLabModulesB(res.getString(1),res.getInt(2),LMnum,WGnum);
				
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
	}
	
	
	
	
	public static void main(String[] args) {
		DbApp app = new DbApp();
		app.dbConnect("ip","name", "username", "password");
		//app.showLabGrades("amka", academic_year, "academic_season");
		// app.showLabGrades("01010104188", 2022, "spring");
		app.insert_RandomLabModulesB("���", 100, 2);
		//app.insert_RandomLabModulesA("���", 100, 2);
		app.dbDisconnect();
		
	
		
	}

}
